#!/usr/bin/env python
# vim: set fileencoding=utf8 shiftwidth=4 tabstop=4 textwidth=80 foldmethod=marker :
# Copyright (c) 2011, Kou Man Tong. All rights reserved.
# For licensing, see LICENSE file included in the package.

import bson.tests

if __name__ == "__main__":
	bson.tests.main()
